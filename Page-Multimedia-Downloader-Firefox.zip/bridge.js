'use strict';

/* ==========================================================================
   Page Multimedia Downloader – bridge (isolated world)

   Receives the records announced by watch.js (which runs in the page's own
   world) and keeps them in window.__pifNetworkVideos, the store that the
   popup's page scan reads. Must be listed BEFORE watch.js in the manifest.
   ========================================================================== */

(() => {
  if (window.__pifBridgeInstalled) return;
  window.__pifBridgeInstalled = true;

  const store = window.__pifNetworkVideos || (window.__pifNetworkVideos = new Map());
  const MAX_ENTRIES = 500;

  window.addEventListener('__pif_net_record', (ev) => {
    try {
      const rec = JSON.parse(String(ev.detail));
      if (!rec || typeof rec.url !== 'string' || !/^(https?|blob|data):/i.test(rec.url)) return;
      if (store.has(rec.url) || store.size >= MAX_ENTRIES) return;
      store.set(rec.url, {
        url: rec.url,
        stream: Boolean(rec.stream),
        initiator: rec.initiator === 'xhr' ? 'xhr' : 'fetch'
      });
    } catch (_) { /* ignore malformed event */ }
  });

  // Ask watch.js to replay anything it saw before this listener existed.
  window.dispatchEvent(new CustomEvent('__pif_net_sync'));
})();
