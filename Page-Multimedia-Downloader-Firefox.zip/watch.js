'use strict';

/* ==========================================================================
   Page Multimedia Downloader – early network watcher (MAIN world)

   Runs at document_start, in every frame, directly in the PAGE's own
   JavaScript world (manifest "world": "MAIN"). That is the only place where
   patching fetch()/XMLHttpRequest actually sees the requests the page's
   players make; a content script in the default isolated world patches its
   own private copies and never sees them.

   Every matching video/playlist URL is kept in a private list and announced
   to bridge.js (isolated world) through DOM events carrying a JSON string.
   Nothing is exposed as a global the page could read or tamper with.

   It also enlarges the Resource Timing buffer so ad-heavy pages do not evict
   the playlist/segment entries before the user scans.
   ========================================================================== */

(() => {
  const FLAG = '__pifWatchInstalled';
  if (window[FLAG]) return;
  try { Object.defineProperty(window, FLAG, { value: true }); } catch (_) { window[FLAG] = true; }

  const EVT_RECORD = '__pif_net_record';
  const EVT_SYNC = '__pif_net_sync';
  const STREAM_RE = /\.(m3u8|m3u|mpd)(?:$|[?#])/i;
  const VIDEO_RE = /\.(mp4|m4v|webm|ogv|ogg|mov|mkv|avi|mpe?g|3gp|flv|wmv|m4s|ts)(?:$|[?#])/i;
  // Pieces of a streamed video are not videos of their own.
  const SEGMENT_RE = /(\.(m4s|ts)|\/(init|seg|segment|chunk|frag|fragment)[-_.\w]*\.mp4)$/i;
  const MAX_ENTRIES = 500;

  const DEBUG = false;
  const seen = new Map();

  function announce(rec) {
    try {
      window.dispatchEvent(new CustomEvent(EVT_RECORD, { detail: JSON.stringify(rec) }));
    } catch (_) { /* ignore */ }
  }

  function record(raw, initiator) {
    try {
      if (raw && typeof raw !== 'string') raw = raw.url || raw.href || String(raw);
      if (typeof raw !== 'string' || !raw) return;
      const url = new URL(raw, document.baseURI).href;
      const stream = STREAM_RE.test(url);
      if (!stream && !VIDEO_RE.test(url)) return;
      if (!stream && SEGMENT_RE.test(url.split(/[?#]/)[0])) return;
      if (seen.has(url)) return;
      if (seen.size >= MAX_ENTRIES) return;
      const rec = { url, stream, initiator };
      seen.set(url, rec);
      if (DEBUG) console.log('[PIF watch] recorded', rec);
      announce(rec);
    } catch (_) { /* ignore */ }
  }

  // The scanner asks for everything seen so far (covers load-order races).
  window.addEventListener(EVT_SYNC, () => {
    for (const rec of seen.values()) announce(rec);
  });

  /* ---- 1. Keep the Resource Timing buffer from filling up ---- */
  try {
    if (performance.setResourceTimingBufferSize) {
      performance.setResourceTimingBufferSize(20000);
      window.addEventListener('resourcetimingbufferfull', () => {
        try {
          performance.setResourceTimingBufferSize(performance.getEntriesByType('resource').length + 20000);
        } catch (_) { /* ignore */ }
      });
    }
  } catch (_) { /* Performance API not available */ }

  /* ---- 2. fetch() ---- */
  try {
    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
      window.fetch = function (input) {
        record(input, 'fetch');
        return origFetch.apply(this, arguments);
      };
      try { Object.defineProperty(window.fetch, 'name', { value: 'fetch' }); } catch (_) { /* ignore */ }
    }
  } catch (_) { /* ignore */ }

  /* ---- 3. XMLHttpRequest ---- */
  try {
    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url) {
      record(url, 'xhr');
      return origOpen.apply(this, arguments);
    };
  } catch (_) { /* ignore */ }

  /* ---- 4. Workers: their own fetch/XHR is out of reach, so just note it ---- */
  if (DEBUG) {
    try {
      const OrigWorker = window.Worker;
      if (typeof OrigWorker === 'function') {
        window.Worker = function (...args) {
          console.warn('[PIF watch] Worker created - its fetch/XHR is not captured:', args[0]);
          return new OrigWorker(...args);
        };
        window.Worker.prototype = OrigWorker.prototype;
      }
    } catch (_) { /* ignore */ }
  }
})();
